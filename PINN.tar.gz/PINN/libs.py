import numpy as np
import torch
import matplotlib.pyplot as plt
import numpy as np
from torch.autograd import Variable
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader
from mpl_toolkits.mplot3d import Axes3D
from scipy.stats import norm
import scipy.io
from matplotlib import cm
import matplotlib.pyplot as plt
import time
from pyDOE import lhs