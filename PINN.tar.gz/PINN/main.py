import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))

from libs import *
from train import *
from net import *
from equation import *

layers = [2, 20, 20, 20, 20, 20, 20, 20, 20, 1]
lr = 0.001
N_f = 2000
N_u = 100
epoch = 5000
error = []
data = scipy.io.loadmat('burgers_shock.mat')

t = data['t'].flatten()[:, None]
x = data['x'].flatten()[:, None]
Exact = np.real(data['usol']).T

X, T = np.meshgrid(x, t)
X_star = np.hstack((X.flatten()[:,None], T.flatten()[:,None]))
u_star = Exact.flatten()[:,None]
lb = X_star.min(0)
ub = X_star.max(0)

xx1 = np.hstack((X[0:1, :].T, T[0:1, :].T))
uu1 = Exact[0:1, :].T
xx2 = np.hstack((X[:, 0:1], T[:, 0:1]))
uu2 = Exact[:, 0:1]
xx3 = np.hstack((X[:, -1:], T[:, -1:]))
uu3 = Exact[:, -1:]

X_u_train = np.vstack([xx1, xx2, xx3])
X_f_train = lb + (ub - lb) * lhs(2, N_f)
X_f_train = np.vstack((X_f_train, X_u_train))
u_train = np.vstack([uu1, uu2, uu3])

idx = np.random.choice(X_u_train.shape[0], N_u, replace=False)
X_u_train = X_u_train[idx, :]
u_train = u_train[idx,:]

net = Net(2, 20, 8, lb, ub)
net.apply(weight_init)
equation = Burgers(net)
#optimizer = optim.LBFGS(net.parameters(),line_search_fn='strong_wolfe')
#scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=1000)
optimizer = optim.Adam(net.parameters())
start = time.time()
for e in range(epoch):
    def closure():
        optimizer.zero_grad()
        loss = equation.loss1(X_f_train, X_u_train, u_train)
        loss.backward()
        return loss
    #loss = equation.loss1(X_f_train, X_u_train, u_train)

    optimizer.zero_grad()
    #loss.backward()
    optimizer.step(closure)
    #scheduler.step()
    loss = closure()
    if (e % 10 == 0):
        end = time.time() - start
        lr = optimizer.state_dict()['param_groups'][0]['lr']
        print("Epoch {} - lr {} -  loss: {} - time:{}".format(e, lr, loss, end))
        error.append(loss.item())


np.savetxt('training_error.csv', error)
torch.save(net, 'net_model2.pkl')
